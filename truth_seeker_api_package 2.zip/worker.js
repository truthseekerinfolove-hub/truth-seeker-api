const ALLOWED_ORIGINS = new Set([
  "https://broad-cloud-199a.truthseekerinfolove.workers.dev"
]);

function corsHeaders(origin) {
  const allowedOrigin = ALLOWED_ORIGINS.has(origin) ? origin : "";
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
    "Access-Control-Allow-Headers": "Content-Type",
    "Vary": "Origin"
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...corsHeaders(origin)
    }
  });
}

function clean(value, max = 1000) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders(origin)
      });
    }

    if (request.method === "GET" && url.pathname === "/") {
      return json({
        service: "Truth Seeker API",
        status: "online",
        message: "API is running. Submit requests using POST /api/requests."
      }, 200, origin);
    }

    if (request.method !== "POST" || url.pathname !== "/api/requests") {
      return json({ error: "Not found" }, 404, origin);
    }

    if (!ALLOWED_ORIGINS.has(origin)) {
      return json({ error: "This website is not allowed to submit requests." }, 403, origin);
    }

    const contentType = request.headers.get("Content-Type") || "";
    if (!contentType.toLowerCase().includes("application/json")) {
      return json({ error: "Send the request as JSON." }, 415, origin);
    }

    let body;
    try {
      const raw = await request.text();
      if (raw.length > 15000) {
        return json({ error: "Request is too large." }, 413, origin);
      }
      body = JSON.parse(raw);
    } catch {
      return json({ error: "The request data could not be read." }, 400, origin);
    }

    const requesterName = clean(body.requesterName, 120);
    const requesterEmail = clean(body.requesterEmail, 254);
    const subjectName = clean(body.subjectName, 160);
    const requestDetails = clean(body.requestDetails, 4000);
    const gender = clean(body.gender, 30);
    const dateOfBirth = clean(body.dateOfBirth, 20);
    const phone = clean(body.phone, 40);
    const publicLinks = clean(body.publicLinks, 1500);
    const consent = body.consent === true;

    if (!requesterName || !requesterEmail || !subjectName || !requestDetails || !consent) {
      return json({
        error: "Please provide your name, email, the person's name, request details, and consent."
      }, 400, origin);
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(requesterEmail)) {
      return json({ error: "Enter a valid email address." }, 400, origin);
    }

    if (!env.DB) {
      return json({ error: "The database is not connected yet. No request was saved." }, 503, origin);
    }

    try {
      const result = await env.DB.prepare(`
        INSERT INTO submissions
        (requester_name, requester_email, subject_name, gender, date_of_birth,
         phone, public_links, request_details, consent, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 'new', datetime('now'))
      `).bind(
        requesterName, requesterEmail, subjectName, gender, dateOfBirth,
        phone, publicLinks, requestDetails
      ).run();

      return json({
        ok: true,
        id: result.meta?.last_row_id ?? null,
        message: "Your request was received. This confirmation does not mean the research is complete."
      }, 201, origin);
    } catch (error) {
      return json({ error: "The request could not be saved. Please try again later." }, 500, origin);
    }
  }
};
