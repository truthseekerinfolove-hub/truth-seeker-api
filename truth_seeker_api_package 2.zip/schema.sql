CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester_name TEXT NOT NULL,
  requester_email TEXT NOT NULL,
  subject_name TEXT NOT NULL,
  gender TEXT,
  date_of_birth TEXT,
  phone TEXT,
  public_links TEXT,
  request_details TEXT NOT NULL,
  consent INTEGER NOT NULL CHECK (consent = 1),
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_submissions_created_at
ON submissions(created_at);

CREATE INDEX IF NOT EXISTS idx_submissions_status
ON submissions(status);
