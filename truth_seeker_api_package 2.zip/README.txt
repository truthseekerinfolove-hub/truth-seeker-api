TRUTH SEEKER API PACKAGE

Files:
- worker.js: Cloudflare Worker API code.
- schema.sql: D1 database table setup.
- frontend-connection-example.js: example of the website submit handler.
- SETUP.txt: deployment steps and important limitations.

IMPORTANT:
This package is a starting implementation. It does not by itself connect the existing website form,
set up email notifications, enforce the three-free-submission offer, or provide an admin dashboard.
Do not accept real customer submissions until you test the complete flow and add appropriate
privacy, security, and retention controls.

Expected D1 binding name: DB
Expected website origin currently configured: https://broad-cloud-199a.truthseekerinfolove.workers.dev
API endpoint: https://truth-seeker-api.truthseekerinfolove.workers.dev/api/requests

The Worker deliberately accepts requests only from the configured site origin. If your website URL
changes, update ALLOWED_ORIGINS before deployment.
