// Example only: adapt the field names to the actual form in index.html.
// Add this logic to the existing form's submit handler; do not replace the whole website with this file.

const TRUTH_SEEKER_API =
  "https://truth-seeker-api.truthseekerinfolove.workers.dev/api/requests";

async function submitTruthSeekerRequest(formData) {
  const response = await fetch(TRUTH_SEEKER_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      requesterName: formData.requesterName,
      requesterEmail: formData.requesterEmail,
      subjectName: formData.subjectName,
      gender: formData.gender || "",
      dateOfBirth: formData.dateOfBirth || "",
      phone: formData.phone || "",
      publicLinks: formData.publicLinks || "",
      requestDetails: formData.requestDetails,
      consent: formData.consent === true
    })
  });

  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Request could not be submitted.");
  return result;
}
